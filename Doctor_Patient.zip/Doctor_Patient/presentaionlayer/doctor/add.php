<?php include ('../../datalayer/bookserver.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Doctor</title>
	<link rel="stylesheet"  href="style3.css">

	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
	<h1>Doctor<span>Patient</span></h1>
		<nav>
			<ul> 
				<li><a href="index2.php">My Info</a></li>
				<li><a href="doctorapp.php">My Appointments</a></li>
				<li><a href="../../applicationlayer/Doctorpatient.php">Logout</a></li>
			</ul>
		</nav>
</header>

</body>
</html>
